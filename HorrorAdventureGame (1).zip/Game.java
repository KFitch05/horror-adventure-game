/**
 * Main game class to demonstrate functionality
 */
public class Game {
    public static void main(String[] args) {
        Player player = new Player("Hero", 100, 20);
        Monster monster = new Monster("Zombie", 50, 10);
        Item potion = new Item("Health Potion", 30);

        // Simulate combat
        monster.takeDamage(player.getAttack());
        player.takeDamage(monster.getAttack());

        // Use item
        potion.use(player);

        // Output results
        System.out.println("Player Health: " + player.getHealth());
        System.out.println("Monster Health: " + monster.getHealth());
    }
}
