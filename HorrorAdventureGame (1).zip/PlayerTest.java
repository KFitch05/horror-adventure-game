public class PlayerTest {
    public static void main(String[] args) {
        Player player = new Player("Test", 100, 15);

        player.takeDamage(20);
        System.out.println("After damage (Expected 80): " + player.getHealth());

        player.heal(10);
        System.out.println("After heal (Expected 90): " + player.getHealth());
    }
}
