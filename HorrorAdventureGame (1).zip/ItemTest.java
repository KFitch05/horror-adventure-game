public class ItemTest {
    public static void main(String[] args) {
        Player player = new Player("Tester", 50, 10);
        Item potion = new Item("Potion", 20);

        potion.use(player);
        System.out.println("After using item (Expected 70): " + player.getHealth());
    }
}
