public class MonsterTest {
    public static void main(String[] args) {
        Monster monster = new Monster("Ghost", 60, 12);

        monster.takeDamage(30);
        System.out.println("After damage (Expected 30): " + monster.getHealth());
    }
}
