/**
 * Monster class represents enemies in the game
 */
public class Monster {
    private String type;
    private int health;
    private int attack;

    public Monster(String type, int health, int attack) {
        this.type = type;
        this.health = health;
        this.attack = attack;
    }

    public String getType() {
        return type;
    }

    public int getHealth() {
        return health;
    }

    public int getAttack() {
        return attack;
    }

    public void takeDamage(int damage) {
        health -= damage;
    }
}
