/**
 * Item class represents usable items
 */
public class Item {
    private String name;
    private int value;

    public Item(String name, int value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public int getValue() {
        return value;
    }

    public void use(Player player) {
        player.heal(value);
    }
}
